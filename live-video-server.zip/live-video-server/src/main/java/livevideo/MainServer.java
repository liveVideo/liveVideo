package livevideo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;

class SerializableImage implements Serializable {

	private static final long serialVersionUID = 1L;
	private byte[] array;

	public SerializableImage(byte[] array) {
		this.array = array;
	}

	public byte[] getBytes() {
		return array;
	}
}

class Recorder extends JFrame {
	private static final long serialVersionUID = 1L;
	private JLabel picLabel;

}

public class MainServer {

	static private ServerSocket socket;;

	private static ObjectInputStream objectInputStream;// TODO

	ByteArrayInputStream bais;

	public static void main(String[] args) throws Exception {

		socket = new ServerSocket(8888);
		Socket clientSocket = socket.accept();
		objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
		int count = 0;
		while (true) {
			String fileName = "fn" + count + ".png";
			File f = new File(fileName);
			f.createNewFile();
			FileOutputStream fs = new FileOutputStream(f);
			SerializableImage serializableImage = (SerializableImage) objectInputStream
					.readObject();
			fs.write(serializableImage.getBytes());
			fs.flush();
			fs.close();
			count++;
		}

	}

}
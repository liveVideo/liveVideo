package livevideo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.commons.io.FileUtils;


class SerializableFile implements Serializable {
	
	private String fileName;

	private static final long serialVersionUID = 1L;
	private byte[] array;

	public SerializableFile(File file) throws IOException {
		fileName = file.getName();		
		this.array = FileUtils.readFileToByteArray(file);
	}
	
	public String getName() {
		return fileName;
	}

	public byte[] getBytes() {
		return array;
	}
}

public class MainServer {
	static private ServerSocket socket;;
	private static ObjectInputStream objectInputStream;
	ByteArrayInputStream bais;

	public static void main(String[] args) throws Exception {
		socket = new ServerSocket(8888);
		Socket clientSocket = socket.accept();
		objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
		while (true) {
			SerializableFile aviFragment = (SerializableFile) objectInputStream.readObject();
			System.out.println("Object read " + aviFragment.getName());
			File f = new File(aviFragment.getName());
			f.createNewFile();
			FileUtils.writeByteArrayToFile(f, aviFragment.getBytes());			
			
		}
	}
}
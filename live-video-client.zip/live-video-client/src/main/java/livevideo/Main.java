package livevideo;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.github.sarxos.webcam.Webcam;

class SerializableImage implements Serializable {

	private static final long serialVersionUID = 1L;
	private byte[] array;

	public SerializableImage(byte[] array) {
		this.array = array;
	}
}

class Recorder extends JFrame {
	private static final long serialVersionUID = 1L;
	private JLabel picLabel;

	private Socket socket;;

	private ObjectOutputStream objectOutputStream;// TODO

	ByteArrayOutputStream baos = new ByteArrayOutputStream();

	public Recorder() throws Exception {
		socket = new Socket("localhost", 8888);
		objectOutputStream = new ObjectOutputStream(socket.getOutputStream());

		picLabel = new JLabel();
		picLabel.setSize(800, 600);
		add(picLabel);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public void setImage(BufferedImage bufferedImage) throws IOException {
		picLabel.setIcon(new ImageIcon(bufferedImage));
		ImageIO.write(bufferedImage, "png", baos);

		objectOutputStream
				.writeObject(new SerializableImage(baos.toByteArray()));

		objectOutputStream.flush();
		baos = new ByteArrayOutputStream();
	}
}

public class Main {
	public static void main(String[] args) throws Exception {
		final Webcam web = Webcam.getDefault();
		web.setViewSize(new Dimension(640, 480));
		web.open();
		final Recorder b = new Recorder();

		b.setSize(800, 600);
		b.show();

		(new Thread(new Runnable() {

			public void run() {
				while (true) {

					try {
						b.setImage(web.getImage());
						// Thread.sleep(50);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			}
		})).start();
	}

}